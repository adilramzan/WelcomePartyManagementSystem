const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "adil@123",
    database: "db_proj1" // Use the correct database name here
});

connection.connect((err) => {
    if (err) throw err;
    console.log("Connected to the database!");
});

// Define a route to create a new database
app.get('/createDatabase', (req, res) => {
    const sql = "CREATE DATABASE IF NOT EXISTS db_proj1";
    connection.query(sql, (err, results) => {
        if (err) throw err;
        res.send(results);
    });
});

app.use(express.static(path.join(__dirname, '')));

// Define a route to serve the dashboard.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});

app.get('/welcome_party', (req, res) => {
    res.sendFile(path.join(__dirname, 'welcome_party.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/user', (req, res) => {
    res.sendFile(path.join(__dirname, 'user.html'));
});


app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'signup.html'));
});
// Define a route for authentication/login
app.get('/authentication/login', (req, res) => {
    const { username, password, confirm_password } = req.query;
    res.json(req.query);
});

// Define a route to create a table named Users for sign-up information
app.get('/createUserTable', (req, res) => {
    const query = `
        CREATE TABLE IF NOT EXISTS Users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL
        )
    `;
    connection.query(query, (err, results) => {
        if (err) {
            console.error('Error creating Users table: ', err);
            return;
        }
        console.log('Users table created successfully');
        res.send(results);
    });
});

// Define a route to redirect to the forgotPassword page
app.get('/forgotPassword', (req, res) => {
    res.sendFile(path.join(__dirname, 'forgotPassword.html'));
});


// Start the server
app.listen(port, () => {
    console.log(`Listening on port ${port}...`);
});


  
// Handle user registration
app.post('/signup', (req, res) => {
    const { username, user_kind, password } = req.body;
    const query = `INSERT INTO main_user (username, user_kind, password) VALUES (?, ?, ?)`;

    connection.query(query, [username, user_kind, password], (err, results) => {
        if (err) {
            console.error('Error inserting into Users table: ', err);
            res.json({ authentication: false });
            return;
        }
        console.log('User registered successfully');
        res.json({ authentication: true });
    });
});


// Handle invitation
app.post('/invitation', (req, res) => {
    const { statusInv, method, user_id } = req.body;
    const invitationQuery = `INSERT INTO invitation (statusInv, method, user_id) VALUES (?, ?, ?)`;

    connection.query(invitationQuery, [statusInv, method, user_id], (invitationErr, invitationResults) => {
        if (invitationErr) {
            console.error('Error inserting into Invitation table: ', invitationErr);
            res.json({ invitation: false });
            return;
        }

        console.log('Invitation created successfully');
        res.json({ invitation: true });
    });
});
  

// Handle task assignment
app.post('/taskassignment', (req, res) => {
    const { organizer_id, task, statusAss } = req.body;
    const taskAssignmentQuery = `INSERT INTO taskassignment (organizer_id, task, statusAss) VALUES (?, ?, ?)`;

    connection.query(taskAssignmentQuery, [organizer_id, task, statusAss], (taskAssignmentErr, taskAssignmentResults) => {
        if (taskAssignmentErr) {
            console.error('Error inserting into Task Assignment table: ', taskAssignmentErr);
            res.json({ taskAssignment: false });
            return;
        }

        console.log('Task Assignment created successfully');
        res.json({ taskAssignment: true });
    });
});

// Handle attendance
app.post('/attendance', (req, res) => {
    const { event_date, family_member_Attendance, user_id } = req.body;
    const attendanceQuery = `INSERT INTO attendance (event_date, family_member_Attendance, user_id) VALUES (?, ?, ?)`;

    connection.query(attendanceQuery, [event_date, family_member_Attendance, user_id], (attendanceErr, attendanceResults) => {
        if (attendanceErr) {
            console.error('Error inserting into Attendance table: ', attendanceErr);
            res.json({ attendance: false });
            return;
        }

        console.log('Attendance created successfully');
        res.json({ attendance: true });
    });
});


// // Handle user login
// app.post('/login', (req, res) => {
//     const { username, password } = req.body;
//     const query = `SELECT * FROM main_user WHERE username = ? AND password = ?`;

//     connection.query(query, [username, password], (err, results) => {
//         if (err) {
//             console.error('Error checking login credentials: ', err);
//             res.json({ authentication: false });
//             return;
//         }

//         if (results.length > 0) {
//             const userKind = results[0].user_kind;

//             // Redirect to the appropriate page based on user_kind
//             switch (userKind) {
//                 case 'student':
//                     res.sendFile(path.join(__dirname, 'student.html'));
//                     break;
//                 case 'manager':
//                     res.sendFile(path.join(__dirname, 'manager.html'));
//                     break;
//                 case 'teacher':
//                 case 'family':
//                     // You can have a common page for teachers and family members
//                     res.sendFile(path.join(__dirname, 'teacher_family.html'));
//                     break;
//                 default:
//                     // Handle other user kinds or show an error page
//                     res.sendFile(path.join(__dirname, 'error_page.html'));
//             }
//         } else {
//             console.log('Invalid credentials');
//             res.json({ authentication: false });
//         }
//     });
// });





// Define a route to handle password reset


// Handle user login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = `SELECT * FROM main_user WHERE username = ? AND password = ?`;

    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error checking login credentials: ', err);
            res.json({ authentication: false });
            return;
        }

        if (results.length > 0) {
            // Redirect to success.html upon successful login
            res.sendFile(path.join(__dirname, 'success.html'));
        } else {
            console.log('Invalid credentials');
            res.json({ authentication: false });
        }
    });
});


app.post('/resetPassword', (req, res) => {
    const { username, newPassword } = req.body;
    
    // Implement logic to update the password in the database
    const query = `UPDATE main_user SET password = ? WHERE username = ?`;

    connection.query(query, [newPassword, username], (err, results) => {
        if (err) {
            console.error('Error resetting password: ', err);
            res.json({ passwordReset: false });
            return;
        }

        if (results.affectedRows > 0) {
            console.log('Password reset successfully');
            res.json({ passwordReset: true });
        } else {
            console.log('Username not found');
            res.json({ passwordReset: false, message: 'Username not found' });
        }
    });
});

// Handle menu suggestion
app.post('/menu_suggestion', (req, res) => {
    const { items, votes, student_id } = req.body;
    const menuSuggestionQuery = `INSERT INTO menu_suggestion (items, votes, student_id) VALUES (?, ?, ?)`;

    connection.query(menuSuggestionQuery, [items, votes, student_id], (menuSuggestionErr, menuSuggestionResults) => {
        if (menuSuggestionErr) {
            console.error('Error inserting into Menu Suggestion table: ', menuSuggestionErr);
            res.json({ menuSuggestion: false });
            return;
        }

        console.log('Menu Suggestion created successfully');
        res.json({ menuSuggestion: true });
    });
});
  

// Handle student registration
app.post('/student', (req, res) => {
    const { username, FName, LName, attribute, familymember, family_id, user_id } = req.body;
    const studentQuery = `
        INSERT INTO student (username, FName, LName, attribute, familymember, family_id, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    connection.query(studentQuery, [username, FName, LName, attribute, familymember, family_id, user_id], (studentErr, studentResults) => {
        if (studentErr) {
            console.error('Error inserting into Student table: ', studentErr);
            res.json({ student: false });
            return;
        }

        console.log('Student created successfully');
        res.json({ student: true });
    });
});


// Handle family registration
app.post('/family', (req, res) => {
    const { username } = req.body;
    const familyQuery = `INSERT INTO family (username) VALUES (?)`;

    connection.query(familyQuery, [username], (familyErr, familyResults) => {
        if (familyErr) {
            console.error('Error inserting into Family table: ', familyErr);
            res.json({ family: false });
            return;
        }

        console.log('Family created successfully');
        res.json({ family: true });
    });
});


//manager

// Handle budget insertion
app.post('/budget', (req, res) => {
    const { manager_id, categor, amount } = req.body;
    const budgetQuery = `
        INSERT INTO budget (manager_id, categor, amount)
        VALUES (?, ?, ?)
    `;

    connection.query(budgetQuery, [manager_id, categor, amount], (budgetErr, budgetResults) => {
        if (budgetErr) {
            console.error('Error inserting into Budget table: ', budgetErr);
            res.json({ budget: false });
            return;
        }

        console.log('Budget entry created successfully');
        res.json({ budget: true });
    });
});


// Handle expense insertion
app.post('/expense', (req, res) => {
    const { manager_id, descriptionExp, amount } = req.body;
    const expenseQuery = `
        INSERT INTO expense (manager_id, descriptionExp, amount)
        VALUES (?, ?, ?)
    `;

    connection.query(expenseQuery, [manager_id, descriptionExp, amount], (expenseErr, expenseResults) => {
        if (expenseErr) {
            console.error('Error inserting into Expense table: ', expenseErr);
            res.json({ expense: false });
            return;
        }

        console.log('Expense entry created successfully');
        res.json({ expense: true });
    });
});


// Handle task assignment insertion
app.post('/taskassignment', (req, res) => {
    const { organizer_id, task_description, statusAss } = req.body;
    const taskAssignmentQuery = `
        INSERT INTO taskassignment (organizer_id, task, statusAss)
        VALUES (?, ?, ?)
    `;

    connection.query(taskAssignmentQuery, [organizer_id, task, statusAss], (taskAssignmentErr, taskAssignmentResults) => {
        if (taskAssignmentErr) {
            console.error('Error inserting into Task Assignment table: ', taskAssignmentErr);
            res.json({ taskAssignment: false });
            return;
        }

        console.log('Task Assignment entry created successfully');
        res.json({ taskAssignment: true });
    });
});


// Handle manager registration
app.post('/manager_registration', (req, res) => {
    const { user_id, FName, LName, managertype } = req.body;
    const managerQuery = `
        INSERT INTO manager (user_id, FName, LName, managertype)
        VALUES (?, ?, ?, ?)
    `;

    connection.query(managerQuery, [user_id, FName, LName, managertype], (managerErr, managerResults) => {
        if (managerErr) {
            console.error('Error inserting into Manager table: ', managerErr);
            res.json({ manager: false });
            return;
        }

        console.log('Manager registered successfully');
        res.json({ manager: true });
    });
});


//teacher

// Handle teacher registration
app.post('/teacher', (req, res) => {
    const { username, FName, LName, familymember, family_id, user_id } = req.body;
    const teacherQuery = `
        INSERT INTO teacher (username, FName, LName, familymember, family_id, user_id)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    connection.query(teacherQuery, [username, FName, LName, familymember, family_id, user_id], (teacherErr, teacherResults) => {
        if (teacherErr) {
            console.error('Error inserting into Teacher table: ', teacherErr);
            res.json({ teacher: false });
            return;
        }

        console.log('Teacher created successfully');
        res.json({ teacher: true });
    });
});


//performance proposal
// Handle performance proposal submission
app.post('/performance_proposal', (req, res) => {
    const { student_id, duration, votes, specialRe, performanceType } = req.body;
    const performanceProposalQuery = `
        INSERT INTO performance_proposal (student_id, duration, votes, specialRe, performanceType)
        VALUES (?, ?, ?, ?, ?)
    `;

    connection.query(
        performanceProposalQuery,
        [student_id, duration, votes, specialRe, performanceType],
        (performanceProposalErr, performanceProposalResults) => {
            if (performanceProposalErr) {
                console.error('Error inserting into Performance Proposal table: ', performanceProposalErr);
                res.json({ performanceProposal: false });
                return;
            }

            console.log('Performance Proposal submitted successfully');
            res.json({ performanceProposal: true });
        }
    );
});
